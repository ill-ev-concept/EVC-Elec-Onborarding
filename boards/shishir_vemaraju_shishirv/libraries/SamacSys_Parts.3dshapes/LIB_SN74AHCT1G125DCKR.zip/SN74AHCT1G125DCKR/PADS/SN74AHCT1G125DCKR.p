*PADS-LIBRARY-PART-TYPES-V9*

SN74AHCT1G125DCKR SOT65P210X110-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.10.10.17.50.39
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHCT1G125DCKR
"Mouser Part Number" 595-SNAHCT1G125DCKR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AHCT1G125DCKR?qs=L5CvrNUdZirUZS97e0eiOw%3D%3D
"Arrow Part Number" SN74AHCT1G125DCKR
"Arrow Price/Stock" https://www.arrow.com/en/products/sn74ahct1g125dckr/texas-instruments.html?utm_currency=USD&region=nac
"Description" Texas Instruments SN74AHCT1G125DCKR, Bus Buffer, 8.5 ns@ 50 pF 8mA, 4.5  5.5 V, 5-Pin SC-70
"Datasheet Link" http://www.ti.com/general/docs/suppproductinfo.tsp?distId=10&gotoUrl=http%3A%2F%2Fwww.ti.com%2Flit%2Fgpn%2Fsn74ahct1g125
"Geometry.Height" 1.1mm
GATE 1 5 0
SN74AHCT1G125DCKR
1 0 U \OE
2 0 U A
3 0 U GND
4 0 U Y
5 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
416119/2192896/2.50/5/3/Integrated Circuit
